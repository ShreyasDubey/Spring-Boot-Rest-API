package com.infy.validator;

import org.apache.commons.logging.LogFactory;

import com.infy.dto.TraineeDTO;
import com.infy.exception.InfyDASystemException;


public class Validator {


	public static void validate(TraineeDTO trainee) throws InfyDASystemException {
	try {
		if(!validateTraineePhoneNo(trainee.getPhoneNo())) {
			throw new InfyDASystemException("Validator.Invalid_Details");
		}
	}catch(InfyDASystemException e) {
		LogFactory.getLog(Validator.class).error(e.getMessage());
		throw e;
	}

	}

	public static Boolean validateTraineePhoneNo(String phoneNo) throws InfyDASystemException {
		String regex ="([789])([0-9]{9})";
		if(phoneNo == null || phoneNo.isBlank()) {
			return false;
		}
		else if(phoneNo.toString().matches(regex)) {
			return true;
		}
		else
			return false;
	}
}

