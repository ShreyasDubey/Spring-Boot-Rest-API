package com.infy.service;

import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.dto.TraineeDTO;
import com.infy.exception.InfyDASystemException;
import com.infy.repository.InfyDASystemRepository;
import com.infy.validator.Validator;


@Service(value = "infyDASystemService")
public class InfyDASystemServiceImpl implements InfyDASystemService {
	@Autowired
	private InfyDASystemRepository infyDASystemRepository;
	
	public TraineeDTO getAllocationDetails(Integer traineeId) throws InfyDASystemException {
		try {
			TraineeDTO receivedTrainee = infyDASystemRepository.getAllocationDetails(traineeId);
			if(receivedTrainee == null) {
				throw new InfyDASystemException("Service.NO_DETAILS_FOUND");
			}
			return receivedTrainee;
		}catch(InfyDASystemException e) {
			LogFactory.getLog(getClass()).error(e.getMessage());
			throw e;
		}
		
	}

	public Integer addNewTrainee(TraineeDTO trainee) throws InfyDASystemException {
		
		try {
			Validator.validate(trainee);
			
			return infyDASystemRepository.addNewTrainee(trainee);
		}
		catch(InfyDASystemException e) {
			LogFactory.getLog(getClass()).error(e.getMessage());
			throw e;
		}
	}

	
}
