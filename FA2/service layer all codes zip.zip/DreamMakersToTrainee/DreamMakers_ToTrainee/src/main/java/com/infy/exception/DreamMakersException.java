package com.infy.exception;

public class DreamMakersException extends Exception {
	private static final long serialVersionUID = 1L;

	public DreamMakersException(String message) {
		super(message);
	}
}
