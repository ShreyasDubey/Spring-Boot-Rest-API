package com.infy.validator;

import com.infy.dto.MovieDTO;
import com.infy.exception.DreamMakersException;

public class Validator {

	public static void validate(MovieDTO movieDTO) throws DreamMakersException {
		if(!validateMovie(movieDTO)) {
			throw new DreamMakersException("Validator.INVALID_NAMES");
		}
	}

	public static Boolean validateMovie(MovieDTO movieDTO) {
		if(movieDTO.getMovieName() == null || movieDTO.getMovieName().isBlank()) {
			return false;
		}
		else if(movieDTO.getDirector() == null || movieDTO.getDirector().getDirectorName() == null|| (movieDTO.getDirector().getDirectorName().isBlank())){
			return false;
		}
		return true;
	}
}
