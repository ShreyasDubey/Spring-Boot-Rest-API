package com.infy.validator;

import org.apache.commons.logging.LogFactory;

import com.infy.dto.TeamMemberDTO;
import com.infy.exception.AbcException;

public class Validator {

	public static void validate(TeamMemberDTO teamMember) throws AbcException {
		try {
			if(!validateEmployeeId(teamMember.getEmployeeId())) {
				throw new AbcException("Validator.INVALID_EMPLOYEEID");
			}
		}catch(AbcException e) {
			
			throw e;
		}
		
	}

	public static Boolean validateEmployeeId(Integer employeeId) throws AbcException {
		if(Math.abs(employeeId) != employeeId) {
			return false;
		}
		else if(employeeId.toString().length() != 6) {
			return false;
		}
		else
			return true;
	}
}
