package com.infy;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.core.env.Environment;

import com.infy.dto.ProjectDTO;
import com.infy.dto.TeamMemberDTO;
import com.infy.exception.AbcException;
import com.infy.service.ProjectService;

@SpringBootApplication
public class AbcToTraineeApplication implements CommandLineRunner{
	public static final Log LOGGER = LogFactory.getLog(AbcToTraineeApplication.class);
	@Autowired
	Environment environment;
	@Autowired
	private ProjectService projectService;
	
	public static void main(String[] args) {
		SpringApplication.run(AbcToTraineeApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

		addProject();
		getProjectDetails();
	}

	public void addProject() {
		try {
			List<TeamMemberDTO> memberList = new ArrayList<>();
			TeamMemberDTO member1 = new TeamMemberDTO();
			member1.setDesignation("SSC");
			member1.setEmployeeId(7229);
			member1.setEmployeeName("Robin");
			member1.setSkills("Java , Oracle");
			TeamMemberDTO member2 = new TeamMemberDTO();
			member2.setDesignation("SSC");
			member2.setEmployeeId(72019);
			member2.setEmployeeName("Monica");
			member2.setSkills("Java, Python");

			memberList.addAll(List.of(member1, member2));
			ProjectDTO project = new ProjectDTO();
			project.setProjectId(5005);
			project.setCost(200000);
			project.setProjectName("FSADM8");
			project.setTeamSize(5);
			project.setTechnologyUsed("Java");
			project.setMemberList(memberList);
			projectService.addProject(project);
			LOGGER.info(environment.getProperty("UserInterface.PROJECT_ADDED_SUCCESS") + project.getProjectId());
		}
		catch(AbcException e) {
			LOGGER.error(environment.getProperty(e.getMessage()));
			
		}
		

	}


	public void getProjectDetails() {
		try {
			List<ProjectDTO> projectList = projectService.getProjectDetails("Jva");
			LOGGER.info(projectList.toString().substring(1,projectList.toString().length()-1));
		}
		catch(AbcException e) {
			LOGGER.error(environment.getProperty(e.getMessage()));
			
		}
	}

}