package com.infy.service;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.dto.ProjectDTO;
import com.infy.dto.TeamMemberDTO;
import com.infy.exception.AbcException;
import com.infy.repository.ProjectRepository;
import com.infy.validator.Validator;

@Service(value = "projectService")
public class ProjectServiceImpl implements ProjectService {

	@Autowired
	public ProjectRepository repository;
	
	@Override
	public Integer addProject(ProjectDTO project) throws AbcException {
		List<TeamMemberDTO> receivedMemberList = project.getMemberList();
		for(TeamMemberDTO receivedMember : receivedMemberList) {
			Validator.validate(receivedMember);
		}
		Integer projectId = repository.addProject(project);
		return projectId;
		
	}


	
	@Override
	public List<ProjectDTO> getProjectDetails(String technology) throws AbcException {
		List<ProjectDTO> receivedProject = repository.getProjectDetails();
		List<ProjectDTO> getProject = receivedProject.stream().filter(project -> project.getTechnologyUsed().equals(technology)).collect(Collectors.toList());
		if(getProject == null || getProject.isEmpty()) {
			throw new AbcException("Service.PROJECTS_NOT_FOUND");
		}
		return getProject;
		
	}


	
}
