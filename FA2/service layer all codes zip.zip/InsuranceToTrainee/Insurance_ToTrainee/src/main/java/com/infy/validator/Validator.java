package com.infy.validator;

import java.time.LocalDate;

import org.apache.commons.logging.LogFactory;

import com.infy.exception.InsuranceException;
import com.infy.model.PolicyDTO;

public class Validator {


	public static void validate(PolicyDTO policy) throws InsuranceException{
		try {
			if(!validatePolicyName(policy.getPolicyName())) {
				throw new InsuranceException("Validator.INVALID_POLICY_NAME");
			}
			if(!validatePolicyType(policy.getPolicyType())) {
				throw new InsuranceException("Validator.INVALID_POLICY_TYPE");
			}
			if(!validatePremium(policy.getPremium())) {
				throw new InsuranceException("Validator.INVALID_PREMIUM");
			}
			if(!validateTenure(policy.getTenureInMonths())) {
				throw new InsuranceException("Validator.INVALID_TENURE");
			}
			if(!validateDateOfBirth(policy.getDateOfBirth())) {
				throw new InsuranceException("Validator.INVALID_DOB");
			}
			if(!validatePolicyNumber(policy.getPolicyNumber(),policy.getPolicyType())) {
				throw new InsuranceException("Validator.INVALID_POLICY_NUMBER");
			}
			if(!validatePolicyHolderName(policy.getPolicyHolderName())) {
				throw new InsuranceException("Validator.INVALID_POLICY_HOLDER_NAME");
			}
		}catch(InsuranceException e) {
			LogFactory.getLog(Validator.class).error(e.getMessage());
			throw e;
		}
	}

	
	public static Boolean validatePolicyName(String policyName){
		String regex = "[A-Za-z]+";
		if(policyName == null || policyName.isBlank()) {
			return false;
		}
		else if(policyName.matches(regex)) {
			return true;
		}
		else 
			return false;
		

	}
	
	public static Boolean validatePolicyType(String policyType){
		if(policyType == "Term Life Insurance" ||
				policyType == "Whole Life Policy" ||
				policyType == "Endowment Plans") {
			return true;
		}
		else
			return false;

	}
	
	public static Boolean validatePremium(Double premium){
		if(premium > 100) {
			return true;
		}
		else
			return false;

	}
	
	public static Boolean validateTenure(Integer tenureInMonths){


		if( tenureInMonths > 24) {
			return true;
		}
		else
			return false;

	}

	
	public static Boolean validateDateOfBirth(LocalDate dateOfBirth){

		if(dateOfBirth.isBefore(LocalDate.now())) {
			return true;
		}
		else
			return false;

	}

	
	public static Boolean validatePolicyNumber(String policyNumber,String policyType){

		String regex1 = "(TL)-([0-9]{6})";
		String regex2 = "(WL)-([0-9]{6})";
		String regex3 = "(EP)-([0-9]{6})";
		if(policyType.equals("Term Life Insurance")){
			if(policyNumber.matches(regex1)) {
				return true;
			}
			return false;
		}
		else if(policyType.equals("Whole Life Policy")){
			if(policyNumber.matches(regex2)) {
				return true;
			}
			return false;
		}
		else if(policyType.equals("Endowment Plans")){
			if(policyNumber.matches(regex3)) {
				return true;
			}
			return false;
		}
		else
			return false;

	}

	
	public static Boolean validatePolicyHolderName(String policyHolderName){
		String regex = "([A-za-z]{3,})( [A-za-z]{3,})*";
		if(policyHolderName.matches(regex)) {
			return true;
		}
		return false;

	}
}
