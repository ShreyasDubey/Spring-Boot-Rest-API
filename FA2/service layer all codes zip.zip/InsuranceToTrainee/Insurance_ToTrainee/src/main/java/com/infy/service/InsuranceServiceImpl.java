package com.infy.service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.infy.exception.InsuranceException;
import com.infy.model.PolicyDTO;
import com.infy.model.PolicyReportDTO;
import com.infy.repository.InsuranceRepository;
import com.infy.validator.Validator;

public class InsuranceServiceImpl implements InsuranceService{
	@Autowired
	private InsuranceRepository insuranceRepository;

	public String buyPolicy(PolicyDTO policy) throws InsuranceException {
		try {
			Validator.validate(policy);
			return insuranceRepository.buyPolicy(policy);
		}
		catch(InsuranceException e) {
			LogFactory.getLog(getClass()).error(e.getMessage());
			throw e;
		}
		
	}

	public Long calculateAge(LocalDate dateOfBirth) throws InsuranceException {
		return ChronoUnit.MONTHS.between(dateOfBirth, LocalDate.now());
	}
	

	public List<PolicyReportDTO> getReport(String policyType) throws InsuranceException {
		try {
			List<PolicyDTO> receivedPolicies = insuranceRepository.getAllPolicyDetails();
			List<PolicyReportDTO> outPolicies = new ArrayList<>();
			final String regex;
			if(policyType.equals("Term Life Insurance"))
				regex = "TL";
			else if(policyType.equals("Whole Life Policy"))
				regex = "WL";
			else if(policyType.equals("Endowment Plans"))
				regex = "EP";
			else
				regex = "";
			List<PolicyDTO> filteredPolicies = receivedPolicies.stream().filter(policy -> policy.getPolicyNumber()
					.substring(0, 2).equals(regex)).collect(Collectors.toList());
			for(PolicyDTO policy: filteredPolicies) {
				PolicyReportDTO newObject = new PolicyReportDTO();
				newObject.setPolicyHolderAge(calculateAge(policy.getDateOfBirth()).doubleValue());
				newObject.setPolicyHolderName(policy.getPolicyHolderName());
				newObject.setPolicyNumber(policy.getPolicyNumber());
				newObject.setTenureInMonths(policy.getTenureInMonths());
				outPolicies.add(newObject);
			}
			if(outPolicies == null || outPolicies.isEmpty()) {
				throw new InsuranceException("Service.NO_RECORD");
			}
			return outPolicies;
		}
		catch(InsuranceException e) {
			LogFactory.getLog(getClass()).error(e.getMessage());
			throw e;
			
		}
		
	}

		
	
	
}
