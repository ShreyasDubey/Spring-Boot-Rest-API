package com.infy.bean;

public class WelcomeBean {
	public String printWelcome() {
		return "Welcome to Spring";
	}
}
